//: Playground - noun: a place where people can play

import UIKit

var numeros = 0...100


for num in numeros{

    if (num % 5 == 0){
        print("\(num) ¡¡BINGO...!! \n")
    }else if  (num % 2 == 0) {
        print("El numero \(num) es Par... \n" )
    }else if  (num % 2 != 0) {
        print("El numero \(num) es Impar... \n ")
    }
    
    switch num{
    case 30...40:
        print("\(num) VIVA SWIFT \n")
    default:
        print(" ")
    }

}


